﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuitCommand : MonoBehaviour
{
    public void QuitGame()
    {
        Debug.Log("This is working");
        Application.Quit();
    }

}
